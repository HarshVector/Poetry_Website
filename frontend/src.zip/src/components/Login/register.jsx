import React from "react";
import { motion } from "framer-motion";

const Register = () => {
  return (
    <div className="relative z-10 flex items-center justify-center min-h-screen bg-gradient-to-b from-gray-100 to-gray-200">
      {/* Background Decorative Elements */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 0.1, scale: 1 }}
        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
        className="absolute inset-0 bg-gradient-to-br from-yellow-400 via-pink-400 to-purple-400 opacity-10 blur-3xl"
      ></motion.div>

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="bg-white shadow-lg rounded-lg p-8 w-full max-w-md relative z-10"
      >
        {/* Header with Animation */}
        <motion.h2
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="text-3xl font-bold text-center mb-6 text-gray-800"
        >
          Register for <span className="text-secondary">Writers Horizon</span>
        </motion.h2>

        {/* Registration Form */}
        <form>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="mb-4"
          >
            <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
              Username
            </label>
            <input
              type="text"
              id="username"
              name="username"
              placeholder="Choose a username"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-secondary focus:border-secondary transition duration-200"
              required
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="mb-4"
          >
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
              Email
            </label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="Enter your email"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-secondary focus:border-secondary transition duration-200"
              required
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.5 }}
            className="mb-4"
          >
            <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
              Password
            </label>
            <input
              type="password"
              id="password"
              name="password"
              placeholder="Create a password"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-secondary focus:border-secondary transition duration-200"
              required
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.5 }}
            className="mb-6"
          >
            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-secondary to-yellow-500 text-white font-semibold rounded-lg hover:bg-opacity-90 transition duration-300 transform hover:scale-105 shadow-lg"
            >
              Register
            </button>
          </motion.div>
        </form>

        {/* Footer Links with Animation */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.5 }}
          className="text-center text-sm text-gray-600"
        >
          <p>
            Already have an account?{" "}
            <a
              href="/login"
              className="text-secondary font-medium hover:underline"
            >
              Login here
            </a>
          </p>
          <p>
            <a
              href="/"
              className="text-secondary font-medium hover:underline"
            >
              Back to Home
            </a>
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Register;
